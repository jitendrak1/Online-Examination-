<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<div id="header">
<img src="images/cooltext1.gif">
</div>

<div id="contact_body">
	<center><div id="link">
	<table>
	<tr><td><a href="index.html"><img src="images/home.png"></a></td>
	<td><a href="admin_log.php"><img src="images/test.png"></a></td>
	<td><a href="regi.html"><img src="images/rg.png"></td>
	<td><a href="result.html"><img src="images/result.png"></td>
	<td><a href="faq.html"><img src="images/faq.png"></td>
	<td><a href="about_us.html"><img src="images/ab.png"></td>
	<td><a href="contact_us.html"><img src="images/contact_us.png"></td></tr>
	</table>
	</div></center><br>
<div id="adm1">
	<div id="admin">
	<img src="images/images.jpeg" height="400px" width="500px">
    </div>
	<div id="ad">

	<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
    <br><br><br><br><br> 
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><font size="5" color="#990000">
	NAME:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></b>&nbsp;&nbsp; 
	<input type="text" name="name" id="f"><br><br><br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><font size="5" color="#990000">
	PASSWORD:</font></b>&nbsp;&nbsp; <input type="password" name="pwd" id="f"><br><br><br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input class="imgbutton" type="submit" value="submit"><br>
	</form>
	<?php
	if($_SERVER['REQUEST_METHOD']=="POST"){
	session_start();
	$con=mysqli_connect("localhost","root","","e_exam");
if(mysqli_connect_errno()){
echo "connection fail".mysqli_connect_error();
}
$cnt=0;
$a=$_POST['name'];
$b=$_POST['pwd'];
$result=mysqli_query($con,"select * from admin");
$row=mysqli_fetch_array($result);
if($row['aid']==$a && $row['pwd']==$b)
{
$cnt=1;
}  
$_SESSION['name']=$a;
$_SESSION['pwd']=$b;
if($cnt==1){
header('location:adminlogin.php');

}
else{ echo "invalid login";}
	}
?>
	</div>
	</div>
	<br><br><br>
<div id="footer">
<h3>Follow Us</h3>
<table><tr><td>
<img src="images/facebook_32.png"></td><td>
<img src="images/youtube_32.png"></td>
<td>
<img src="images/twitter_32.png"></td>
<td>
<img src="images/google_32.png"></td></tr>

</table></div>


</body>
</html>
