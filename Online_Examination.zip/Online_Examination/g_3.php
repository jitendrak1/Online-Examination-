<html>
<body>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
<p>12. The Parliament of India cannot be regarded as a sovereign body because

</p>
<input type="radio" name="1" value="a">A.	it can legislate only on subjects entrusted to the Centre by the Constitution<br>
<input type="radio" name="1" value="b">B.	it has to operate within the limits prescribed by the Constitution<br>
<input type="radio" name="1" value="c">C.	the Supreme Court can declare laws passed by parliament as unconstitutional if they contravene the provisions of the Constitution<br>
<input type="radio" name="1" value="d">D.	All of the above<br>
<input type="submit" value="submit">
</form>
<?php
session_start();
$a=$_SESSION['uname'];
echo $a."<br>";
if($_SERVER['REQUEST_METHOD']=="POST"){
$abc=$_POST['1'];

$con=mysqli_connect("localhost","root","","e_exam");
if(mysqli_connect_errno()){
echo "connection fail".mysqli_connect_error();
} 
$result=mysqli_query($con,"select * from question where q_no=12");
$row=mysqli_fetch_array($result);
if($row['ans']==$abc)
{
  mysqli_query($con,"update exam set ryt='1',wrong=NULL where e_uid='$a' and e_q_no=12");
}
else
{
 mysqli_query($con,"update exam set ryt=null,wrong='1' where e_uid='$a' and e_q_no=12");
}
echo "This was last Question";
}

?>
</body>
</html>