<html>
<body>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
<p>6. Running at the same constant rate, 6 identical machines can produce a total of 270 bottles per minute. At this rate, how many bottles could 10 such machines produce in 4 minutes? 
	
	
</p>
<input type="radio" name="1" value="a">A.	648<br>
<input type="radio" name="1" value="b">B.	1800<br>
<input type="radio" name="1" value="c">C.	2700<br>
<input type="radio" name="1" value="d">D.	10800<br>
<input type="submit" value="submit">
</form>
<?php
session_start();
$a=$_SESSION['uname'];
echo $a."<br>";
if($_SERVER['REQUEST_METHOD']=="POST"){
$abc=$_POST['1'];

$con=mysqli_connect("localhost","root","","e_exam");
if(mysqli_connect_errno()){
echo "connection fail".mysqli_connect_error();
} 
$result=mysqli_query($con,"select * from question where q_no=6");
$row=mysqli_fetch_array($result);
if($row['ans']==$abc)
{
  mysqli_query($con,"update exam set ryt='1',wrong=NULL where e_uid='$a' and e_q_no=6");
}
else
{
 mysqli_query($con,"update exam set ryt=null,wrong='1' where e_uid='$a' and e_q_no=6");
}
header('location:r_1.php');
}

?>
</body>
</html>