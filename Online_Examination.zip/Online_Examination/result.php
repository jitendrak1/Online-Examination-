<html>
<body>
      <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
	  <label for="uid">Username</label>
	  <input type="text" id="uid" name="uname"><br>
	  <label for="pwd">Password</label>
	  <input type="password" id="pwd" name="pwd"><br>
	  <input type="submit" value="submit">
	  </form>
<?php
	
	$p=0;
	
	$con=mysqli_connect("localhost","root","","e_exam");
if(mysqli_connect_errno()){
echo "connection fail".mysqli_connect_error();
}
$z=mysqli_query($con,"select * from status");
while($w=mysqli_fetch_array($z)){
if($w['status']=='result show')
 $p=1; 
}
if($p==1){
if($_SERVER['REQUEST_METHOD']=="POST")
	{
		
    echo "<h1>write php result code</h1>";
$a=$_POST['uname'];
$b=$_POST['pwd'];
$f=0;
$g=0;

$result=mysqli_query($con,"select * from student_reg");
while($y=mysqli_fetch_array($result)){
if($y['uid']==$a && $y['pwd']==$b){
$f=1;

}
}
if($f==1)
{
	$res=mysqli_query($con,"select * from result");
	while($x=mysqli_fetch_array($res)){
	     if($x['r_uid']==$a &&($x['math']>0 || $x['english']>0 || $x['gk']>0 || $x['reasoning']>0)){ $g=1;}
	}
	if($g==1)
	{
		while($x=mysqli_fetch_array($res)){
		echo "<table border=1><tr>
		<th>Username</th>
		<th>Maths</th>
		<th>English</th>
		<th>GK</th>
		<th>Reasoning</th></tr>";
		
		
		echo "<tr><td>";
		echo $x['r_uid'];
		echo "</td>";
		echo "<td>";
		echo $x['math'];
		echo "</td>";
		echo "<td>";
		echo $x['english'];
		echo "</td>";
		echo "<td>";
		echo $x['gk'];
		echo "</td>";
		echo "<td>";
		echo $x['reasoning'];
		echo "</td>";
		echo "</tr></table>";
		
}
		
	}
	else{
		echo "you have not appeared";
	}
}
else{
 echo "you are not registered candidate. ";
 }
 }
 }
 else{
 echo "<h1> Result not Published</h1>";
 }

?>