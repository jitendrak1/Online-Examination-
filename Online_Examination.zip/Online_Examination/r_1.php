<html>
<body>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
<p>7. Look at this series: 36, 34, 30, 28, 24, ... What number should come next?
	
	

</p>
<input type="radio" name="1" value="a">A.	20<br>
<input type="radio" name="1" value="b">B.	22<br>
<input type="radio" name="1" value="c">C.	23<br>
<input type="radio" name="1" value="d">D.	26<br>
<input type="submit" value="submit">
</form>
<?php
session_start();
$a=$_SESSION['uname'];
echo $a."<br>";
if($_SERVER['REQUEST_METHOD']=="POST"){
$abc=$_POST['1'];

$con=mysqli_connect("localhost","root","","e_exam");
if(mysqli_connect_errno()){
echo "connection fail".mysqli_connect_error();
} 
$result=mysqli_query($con,"select * from question where q_no=7");
$row=mysqli_fetch_array($result);
if($row['ans']==$abc)
{
  mysqli_query($con,"update exam set ryt='1',wrong=NULL where e_uid='$a' and e_q_no=7");
}
else
{
 mysqli_query($con,"update exam set ryt=null,wrong='1' where e_uid='$a' and e_q_no=7");
}
header('location:r_2.php');
}

?>
</body>
</html>