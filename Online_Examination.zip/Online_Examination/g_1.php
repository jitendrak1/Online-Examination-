<html>
<body>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
<p>10. Who is the father of Geometry?
	
	
</p>
<input type="radio" name="1" value="a">A.	Aristotle<br>
<input type="radio" name="1" value="b">B.	Euclid<br>
<input type="radio" name="1" value="c">C.	Pythagoras<br>
<input type="radio" name="1" value="d">D.	Kepler<br>
<input type="submit" value="submit">
</form>
<?php
session_start();
$a=$_SESSION['uname'];
echo $a."<br>";
if($_SERVER['REQUEST_METHOD']=="POST"){
$abc=$_POST['1'];

$con=mysqli_connect("localhost","root","","e_exam");
if(mysqli_connect_errno()){
echo "connection fail".mysqli_connect_error();
} 
$result=mysqli_query($con,"select * from question where q_no=10");
$row=mysqli_fetch_array($result);
if($row['ans']==$abc)
{
  mysqli_query($con,"update exam set ryt='1',wrong=NULL where e_uid='$a' and e_q_no=10");
}
else
{
 mysqli_query($con,"update exam set ryt=null,wrong='1' where e_uid='$a' and e_q_no=10");
}
header('location:g_2.php');
}

?>
</body>
</html>