<html>
<body>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
<p>3. The small child does whatever his father was done.
	
	
</p>
<input type="radio" name="1" value="a">A.	has done<br>
<input type="radio" name="1" value="b">B.	did<br>
<input type="radio" name="1" value="c">C.	does<br>
<input type="radio" name="1" value="d">D.	had done<br>
<input type="radio" name="1" value="e">E.	No correction required<br>
<input type="submit" value="submit">
</form>
<?php
session_start();
$a=$_SESSION['uname'];
echo $a."<br>";
if($_SERVER['REQUEST_METHOD']=="POST"){
$abc=$_POST['1'];

$con=mysqli_connect("localhost","root","","e_exam");
if(mysqli_connect_errno()){
echo "connection fail".mysqli_connect_error();
} 
$result=mysqli_query($con,"select * from question where q_no=3");
$row=mysqli_fetch_array($result);
if($row['ans']==$abc)
{
  mysqli_query($con,"update exam set ryt='1',wrong=NULL where e_uid='$a' and e_q_no=3");
}
else
{
 mysqli_query($con,"update exam set ryt=null,wrong='1' where e_uid='$a' and e_q_no=3");
 
}
header('location:m_1.php');
}
?>
</body>
</html>