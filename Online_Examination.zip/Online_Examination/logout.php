<?php
session_start();
$a=$_SESSION['uname'];

$con=mysqli_connect("localhost","root","","e_exam");
if(mysqli_connect_errno()){
echo "connection fail".mysqli_connect_error();
} 

$eng=0;
$math=0;
$resoning=0;
$g_k=0;
$result=mysqli_query($con,"select * from exam where e_uid='$a'");
while($row=mysqli_fetch_array($result)){
 if($row['e_q_no']>=1 && $row['e_q_no']<=3 && $row['ryt']==1){
 $eng=$eng+1;
 echo "<br>".$eng;
 }
 if($row['e_q_no']>=4 && $row['e_q_no']<=6 && $row['ryt']==1){
 $math=$math+1;
 echo "<br>".$math;
 }
 
 if($row['e_q_no']>=7 && $row['e_q_no']<=9 && $row['ryt']==1){
 $resoning=$resoning+1;
 echo "<br>".$resoning;
 }
 
 if($row['e_q_no']>=10 && $row['e_q_no']<=12 && $row['ryt']==1){
 $g_k=$g_k+1;
 echo "<br>".$g_k;
 }
 
}
echo "<br>"."update";
mysqli_query($con,"update result set math=$math,english=$eng,gk=$g_k,reasoning=$resoning where r_uid='$a'");

mysqli_query($con,"delete from exam where e_uid='$a'");
mysqli_query($con,"update student_reg set stat='stop' where uid='$a'");
header('Location:index.html');
?>
