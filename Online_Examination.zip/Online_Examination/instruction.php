<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<div id="header">
<img src="images/cooltext1.gif">
</div>

<div id="contact_body">
	<center><div id="link">
	<table>
	<tr><td><a href="index.html"><img src="images/home.png"></a></td>
	<td><a href="admin_log.php"><img src="images/test.png"></a></td>
	<td><a href="regi.html"><img src="images/rg.png"></td>
	<td><a href="result.html"><img src="images/result.png"></td>
	<td><a href="faq.html"><img src="images/faq.png"></td>
	<td><a href="about_us.html"><img src="images/ab.png"></td>
	<td><a href="contact_us.html"><img src="images/contact_us.png"></td></tr>
	</table>
	</div></center><br>
  <div id="ins">
	<center><h1>INSTRUCTION FOR ST</h1></center>
&nbsp;&nbsp;<h2>Please read the following instructions very carefully:</h2> 
 <ol type="1">
 <h3><li>Read carefully the instructions before starting the test.you can read the instructions in between the exam after clicking the "INSTRUCTION BUTTON".</li>
 <li>You have 120 minutes to complete the test.</li>
 <li>The test contains a total of 200 questions.</li>
 <li>There is only one correct answer to each question. Click on the most appropriate option to mark it as your answer.</li>
 <li>You will be awarded 1 marks for each correct answer.</li>
 <li>Do not click the button SUBMIT TEST before completing the test. A test once submitted cannot be resumed.</li>
 <li>Once clicked on the (SUBMIT TEST) button, You Cannot REDO this Speed Test.....</li></h3>
 </ol> <br><br>
  <center><a href="exam1.php"><img src="images/ready.png"></a></center>
</div><br>	
</div>


<div id="footer">
<h3>Follow Us</h3>
<table><tr><td>
<img src="images/facebook_32.png"></td><td>
<img src="images/youtube_32.png"></td>
<td>
<img src="images/twitter_32.png"></td>
<td>
<img src="images/google_32.png"></td></tr>

</table></div>
<?php
session_start();
$a=$_SESSION['uname'];
?>
</body>
</html>
