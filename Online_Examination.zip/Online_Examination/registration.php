 <?php
 
$con=mysqli_connect("localhost","root","","e_exam");
if(mysqli_connect_errno()){
echo "connection fail".mysqli_connect_error();
} 

$a=$_POST['firstname'];
$b=$_POST['lastname'];
$c=$_POST['mob'];
$d=$_POST['email'];
$e=$_POST['pass'];
$f=$_POST['sex'];
                                  
                                
$x=mysqli_query($con,"insert into student_reg values('$a','$b','$c','$d','$e','$f','start')");
header('location:index.html');
?>

