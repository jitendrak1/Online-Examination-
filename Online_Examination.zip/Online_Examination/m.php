<html>
<body>
<?php

?>
<form action="m.php" method="POST">
Inter the sabhansnsaojvalue<input type="text" name="r" id="r">
<input type="submit" value="submit">
</form>
</body>
</html>