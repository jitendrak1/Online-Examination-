<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<div id="header">
<img src="images/cooltext1.gif">
</div>

<div id="contact_body">
	<center><div id="link">
	<table>
	<tr><td><a href="index.html"><img src="images/home.png"></a></td>
	<td><a href="admin_log.php"><img src="images/test.png"></a></td>
	<td><a href="regi.html"><img src="images/rg.png"></td>
	<td><a href="result.html"><img src="images/result.png"></td>
	<td><a href="faq.html"><img src="images/faq.png"></td>
	<td><a href="about_us.html"><img src="images/ab.png"></td>
	<td><a href="contact_us.html"><img src="images/contact_us.png"></td></tr>
	</table>
	</div></center><br>
<div id="adm1">
	<div id="admin">
	<img src="images/images.jpeg" height="400px" width="500px">
    </div>
	<div id="ad">


<?php 
session_start();
$con=mysqli_connect("localhost","root","","e_exam");
if(mysqli_connect_errno()){
echo "connection fail".mysqli_connect_error();
}

 echo "<form method='POST'>";
 echo "<input name='b1' type='submit' value='Start Exam'>";
 echo "<input name='b2' type='submit' value='Stop Exam'>";
 echo "<input name='b3' type='submit' value='Result Show'>";
 echo "<input name='b4' type='submit' value='Result Stop'>";
 echo "</form>";




if(isset($_POST['b1']))
{
mysqli_query($con,"update status set status='start exam'");
mysqli_query($con,"update student_reg set stat='start'");
}


if(isset($_POST['b2']))
{
mysqli_query($con,"update status set status='stop exam'");
mysqli_query($con,"update student_reg set stat='stop'");
}


if(isset($_POST['b3']))
{
mysqli_query($con,"update status set status='result show'");
}


if(isset($_POST['b4']))
{
mysqli_query($con,"update status set status='result stop'");
}

echo "<form action='admin_log.php'>";
echo "<input type='submit' value='logout'>";
echo "</form>";
?>

</div>
	</div>
	<br><br><br>
<div id="footer">
<h3>Follow Us</h3>
<table><tr><td>
<img src="images/facebook_32.png"></td><td>
<img src="images/youtube_32.png"></td>
<td>
<img src="images/twitter_32.png"></td>
<td>
<img src="images/google_32.png"></td></tr>

</table></div>

</body>
</html>
