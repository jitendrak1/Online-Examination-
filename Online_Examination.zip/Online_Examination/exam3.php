<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<?php
session_start();
$a=$_SESSION['uname'];

?>
<div id="header">
<img src="images/cooltext1.gif">
</div>
<div id="exambutton">
     <a href="exam1.php"><img src="images/english.png"></a>
     <a href="exam2.php"><img src="images/maths.png"></a>
	 <a href="exam3.php"><img src="images/reasoning.png"></a>
	 <a href="exam4.php"><img src="images/gk.png"></a>
	 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	 &nbsp;&nbsp;
	 <a href="logout.php"><img src="images/elogout.png"></a>
</div>
  <div id="exam1">
    
	<!--Question code -->
	<iframe width="945px" height="547px" name="ifrm">
    

   
    </iframe>	
</div>

<div id="qusno"> 
		<input class="question_no" type="submit" value="1" onclick="ifrm.location.href='r_1.php'"></input>
		<input class="question_no" type="submit" value="2" onclick="ifrm.location.href='r_2.php'"></input>
		<input class="question_no" type="submit" value="3" onclick="ifrm.location.href='r_3.php'"></input>
		<input class="question_no" type="submit" value="4" onclick="ifrm.location.href='r_4.php'"></input>
		<input class="question_no" type="submit" value="5" onclick="ifrm.location.href='r_5.php'"></input>
		<input class="question_no" type="submit" value="6" onclick="ifrm.location.href='r_6.php'"></input>
		<input class="question_no" type="submit" value="7" onclick="ifrm.location.href='r_7.php'"></input>
		<input class="question_no" type="submit" value="8" onclick="ifrm.location.href='l.html'"></input>
		<input class="question_no" type="submit" value="9" onclick="ifrm.location.href='l.html'"></input>
		<input class="question_no" type="submit" value="10" onclick="ifrm.location.href='l.html'"></input>
		
	</div>	

<br>	
</div>

<div id="footer">
<h3>Follow Us</h3>
<table><tr><td>
<img src="images/facebook_32.png"></td><td>
<img src="images/youtube_32.png"></td
<td>
<img src="images/twitter_32.png"></td>
<td>
<img src="images/google_32.png"></td></tr>

</table></div>

</body>
</html>
