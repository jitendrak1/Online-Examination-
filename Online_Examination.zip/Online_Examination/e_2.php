<html>
<body>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
<p>2. When he 
P :	did not know 
Q :	he was nervous and 
R :	heard the hue and cry at midnight 
S :	what to do 
The Proper sequence should be:
	
	

</p>
<input type="radio" name="1" value="a">A.	RQPS<br>
<input type="radio" name="1" value="b">B.	QSPR<br>
<input type="radio" name="1" value="c">C.	SQPR<br>
<input type="radio" name="1" value="d">D.	PQRS<br>
<input type="submit" value="submit">
</form>
<?php
session_start();
$a=$_SESSION['uname'];
echo $a."<br>";
if($_SERVER['REQUEST_METHOD']=="POST"){
$abc=$_POST['1'];

$con=mysqli_connect("localhost","root","","e_exam");
if(mysqli_connect_errno()){
echo "connection fail".mysqli_connect_error();
} 
$result=mysqli_query($con,"select * from question where q_no=2");
$row=mysqli_fetch_array($result);
if($row['ans']==$abc)
{
  mysqli_query($con,"update exam set ryt='1',wrong=NULL where e_uid='$a' and e_q_no=2");
}
else
{
 mysqli_query($con,"update exam set ryt=null,wrong='1' where e_uid='$a' and e_q_no=2");
}
header('location:e_3.php');
}

?>
</body>
</html>