<?php
session_start();
$con=mysqli_connect("localhost","root","","e_exam");
if(mysqli_connect_errno()){
echo "connection fail".mysqli_connect_error();
}
                         
$a=$_POST['uname'];
$b=$_POST['pwd'];
$f=0;
$z=0;
$y=0;
  $_SESSION['uname']=$a;
  
  $x=mysqli_query($con,"select * from status" );
  while($row=mysqli_fetch_array($x)){
	if($row['status']=="start exam"){
	$y=1;
	}
  
  }
  
  if($y==1){
$x=mysqli_query($con,"select * from student_reg" );
while($row=mysqli_fetch_array($x)){
if($a==$row['uid'] && $b==$row['pwd']){
$z=1;
if($row['stat']=="start"){

while($x<=12){
mysqli_query($con,"insert into exam values('$a','$x',NULL,NULL)");
$x=$x+1;
} 
mysqli_query($con,"insert into result values('$a',0,0,0,0)");                    
header('Location:instruction.php');
}
}
}
	$w=mysqli_query($con,"select * from student_reg where uid='$a' and pwd='$b'" );
	$row=mysqli_fetch_array($w);
if($row['stat']!="start"){
$m=1;

}
if($z==0){
	echo "Invalid user";

  }
else if($m==1){	

    echo "do not try again, your exam over.!!!!";
}  
}
else{

	echo "Exam not started";
}                                

?>